Add-Type -AssemblyName System.Drawing
$iconPath = $args[0]
$outDir = $args[1]
$ico = New-Object System.Drawing.Icon($iconPath)

$sizes = @(32, 128, 256)
foreach ($s in $sizes) {
    $bmp = $ico.ToBitmap()
    $wb = New-Object System.Drawing.Bitmap($s, $s)
    $g = [System.Drawing.Graphics]::FromImage($wb)
    $g.InterpolationMode = 'HighQualityBicubic'
    $g.DrawImage($bmp, 0, 0, $s, $s)
    $name = "${s}x${s}.png"
    $path = Join-Path $outDir $name
    $wb.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    Write-Host "OK $path"
    $g.Dispose()
    $wb.Dispose()
    $bmp.Dispose()
}

# 128@2x = 256 尺寸
$bmp2 = $ico.ToBitmap()
$wb2 = New-Object System.Drawing.Bitmap(256, 256)
$g2 = [System.Drawing.Graphics]::FromImage($wb2)
$g2.InterpolationMode = 'HighQualityBicubic'
$g2.DrawImage($bmp2, 0, 0, 256, 256)
$p2 = Join-Path $outDir '128x128@2x.png'
$wb2.Save($p2, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Host "OK $p2"
$g2.Dispose()
$wb2.Dispose()
$bmp2.Dispose()

# icon.ico 复制
Copy-Item $iconPath (Join-Path $outDir 'icon.ico') -Force
Write-Host "OK icon.ico copied"
$ico.Dispose()
