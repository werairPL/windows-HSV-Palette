fn main() {
    // 显式监听前端目录变化：改 HTML/CSS/JS 后强制重嵌资产（默认 tauri-build 不监听 ../app）
    println!("cargo:rerun-if-changed=../app");
    println!("cargo:rerun-if-changed=../app/index.html");
    tauri_build::build()
}
