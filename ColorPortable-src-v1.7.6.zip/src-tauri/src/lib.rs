use serde::{Deserialize, Serialize};
use serde_json::json;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicIsize, AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::Duration;
use tauri::{Emitter, Manager, WebviewWindowBuilder};

// Windows 下窗口 subclass 拦截 WM_SIZING：拖动中直接修正矩形，实现实时宽高比锁定
#[cfg(windows)]
use windows_sys::Win32::Foundation::{HWND, LPARAM, LRESULT, RECT, WPARAM};
#[cfg(windows)]
use windows_sys::Win32::Graphics::Gdi::{
    GetMonitorInfoW, MonitorFromWindow, MONITORINFO, MONITOR_DEFAULTTONEAREST,
};
#[cfg(windows)]
use windows_sys::Win32::UI::HiDpi::GetDpiForWindow;
#[cfg(windows)]
use windows_sys::Win32::UI::WindowsAndMessaging::*;

/// 配置文件：窗口 bounds + 主题，存于 exe 同目录（便携携带）
#[derive(Debug, Default, Serialize, Deserialize, Clone)]
struct AppConfig {
    #[serde(skip_serializing_if = "Option::is_none")]
    window: Option<WindowBounds>,
    #[serde(skip_serializing_if = "Option::is_none")]
    theme: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct WindowBounds {
    width: f64,
    height: f64,
    #[serde(skip_serializing_if = "Option::is_none")]
    x: Option<i32>,
    #[serde(skip_serializing_if = "Option::is_none")]
    y: Option<i32>,
}

/// 宽高比（与前端 .scaled 的 660×880 对应）
const RATIO: f64 = 660.0 / 880.0;

/// 记录最近一次窗口实际报告的尺寸（逻辑尺寸），用于方向感知判向
struct LastSize(Mutex<Option<(f64, f64)>>);

/// 缩放防抖：拖动中不干预，停止后延迟校正一次。
/// `gen` 为代数令牌——每次 Resized 递增，延迟线程醒来时若代数已过期则放弃，
/// 保证只有"最后一次停止变化"才真正动窗口，杜绝拖动时来回拉锯抽搐。
/// `target` 存放待校正的目标尺寸（逻辑），由防抖线程读取后交给动画校正。
/// `animating` 标记插值动画进行中：动画自帧触发的 Resized 不再调度新校正，避免自激。
struct ResizeDebounce {
    gen: AtomicU64,
    target: Mutex<Option<(f64, f64)>>,
    animating: AtomicBool,
}

/// 返回 exe 所在目录下的配置文件路径（便携：随 exe 携带）
fn config_path() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|d| d.join("colorpicker-config.json")))
        .unwrap_or_else(|| PathBuf::from("colorpicker-config.json"))
}

fn load_config() -> AppConfig {
    std::fs::read_to_string(config_path())
        .ok()
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or_default()
}

fn save_config(cfg: &AppConfig) {
    if let Ok(s) = serde_json::to_string_pretty(cfg) {
        let _ = std::fs::write(config_path(), s);
    }
}

/// 窗口控制 commands
#[tauri::command]
fn win_minimize(app: tauri::AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        let _ = w.minimize();
    }
}

#[tauri::command]
fn win_toggle_maximize(app: tauri::AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        if w.is_maximized().unwrap_or(false) {
            let _ = w.unmaximize();
        } else {
            let _ = w.maximize();
        }
    }
}

#[tauri::command]
fn win_close(app: tauri::AppHandle) {
    if let Some(w) = app.get_webview_window("main") {
        remember_bounds(&app);
        let _ = w.close();
    }
}

#[tauri::command]
fn config_load() -> AppConfig {
    load_config()
}

#[tauri::command]
fn config_save(cfg: AppConfig) {
    save_config(&cfg);
}

/// 保存当前窗口 bounds（物理坐标 → 逻辑尺寸）
fn remember_bounds(app: &tauri::AppHandle) {
    let Some(window) = app.get_webview_window("main") else { return };
    let Ok(outer) = window.outer_position() else { return };
    let Ok(size) = window.outer_size() else { return };
    let scale = window.scale_factor().unwrap_or(1.0);
    let mut cfg = load_config();
    cfg.window = Some(WindowBounds {
        width: size.width as f64 / scale,
        height: size.height as f64 / scale,
        x: Some(outer.x),
        y: Some(outer.y),
    });
    save_config(&cfg);
}

/// 校验并按宽高比校正尺寸（逻辑尺寸）
/// 方向感知：检测用户是横向还是纵向拖动，保留被拖动的边、按比例修正另一边，
/// 这样拖动跟手不闪变。若两边都变（拖角），以高度为基准。
fn enforce_aspect(logical_w: f64, logical_h: f64, last_w: f64, last_h: f64) -> (f64, f64) {
    let ratio = RATIO;
    let dw = (logical_w - last_w).abs();
    let dh = (logical_h - last_h).abs();
    // 拖宽（宽度变化明显、高度基本没变）：保留宽度，按比例推高度
    if dw > 1.0 && dh <= 1.0 {
        let w = logical_w.max(406.0);
        let h = (w / ratio).max(542.0);
        (w, h)
    // 拖高（高度变化明显、宽度基本没变）：保留高度，按比例推宽度
    } else if dh > 1.0 && dw <= 1.0 {
        let h = logical_h.max(542.0);
        let w = (h * ratio).max(406.0);
        (w, h)
    // 两边都动（拖角）或初值：以高度为基准
    } else {
        let h = logical_h.max(542.0);
        let w = (h * ratio).max(406.0);
        (w, h)
    }
}

/// 平滑过渡校正：从当前窗口尺寸插值到目标尺寸，避免松手时一步猛跳的鬼畜感。
/// 逐帧 set_size 触发的 Resized 会被 handler 中的 `animating` 标志抑制，不会自激。
/// 动画期间若用户中途拖动，结束时做一次最终校验，失配则补一次防抖。
fn animate_resize(win: &tauri::WebviewWindow, handle: tauri::AppHandle, target_w: f64, target_h: f64) {
    let scale = win.scale_factor().unwrap_or(1.0);
    let Ok(outer) = win.outer_size() else { return };
    let cur_w = outer.width as f64 / scale;
    let cur_h = outer.height as f64 / scale;
    let (dw, dh) = (target_w - cur_w, target_h - cur_h);
    // 已到位（或近乎到位）则无需动画
    if dw.abs() + dh.abs() < 1.0 {
        return;
    }
    const STEPS: u32 = 18; // 约 300ms @ 16ms/帧
    let debounce = handle.state::<ResizeDebounce>();
    debounce.animating.store(true, Ordering::SeqCst);
    for i in 1..=STEPS {
        let t = i as f64 / STEPS as f64;
        let _ = win.set_size(tauri::LogicalSize::new(cur_w + dw * t, cur_h + dh * t));
        std::thread::sleep(Duration::from_millis(16));
    }
    debounce.animating.store(false, Ordering::SeqCst);

    // 最终校验：动画期间若用户中途拖动，最终尺寸可能仍失配 → 补一次防抖
    let debounce = handle.state::<ResizeDebounce>();
    let (lw, lh) = match win.outer_size() {
        Ok(outer) => (outer.width as f64 / scale, outer.height as f64 / scale),
        Err(_) => return,
    };
    let last = *handle.state::<LastSize>().0.lock().unwrap();
    let (tw, th) = match last {
        Some((a, b)) => enforce_aspect(lw, lh, a, b),
        None => enforce_aspect(lw, lh, lw, lh),
    };
    if (tw - lw).abs() > 2.0 || (th - lh).abs() > 2.0 {
        let gen = debounce.gen.fetch_add(1, Ordering::SeqCst) + 1;
        *debounce.target.lock().unwrap() = Some((tw, th));
        let win_c = win.clone();
        std::thread::spawn(move || {
            std::thread::sleep(Duration::from_millis(200));
            let debounce = handle.state::<ResizeDebounce>();
            if debounce.gen.load(Ordering::SeqCst) == gen {
                if let Some((tw, th)) = *debounce.target.lock().unwrap() {
                    animate_resize(&win_c, handle.clone(), tw, th);
                }
            }
        });
    }
}

// ─── WM_SIZING 实时宽高比锁定（Windows 原生层） ────────────────────────────
// 窗口拖动过程中 Windows 每个 frame 都会发 WM_SIZING，并把"建议矩形"交给我们。
// 我们直接在窗口过程里把矩形修正成 0.75 比例，Windows 就按修正后的矩形去设窗口——
// 因此边框拖动过程中每一步都是正确比例（真·实时锁定），松手即已到位，无滞后。
// 注意 WM_SIZING 只在真实 resize 拖动期间发送，不会与 MoveWindow/set_size 冲突。

/// 保存被替换掉的旧窗口过程指针，供转发消息与 WM_DESTROY 时恢复
#[cfg(windows)]
static OLD_WNDPROC: AtomicIsize = AtomicIsize::new(0);

/// 当前窗口所在显示器的可用工作区（屏幕坐标、物理像素）
#[cfg(windows)]
fn monitor_work_area(hwnd: HWND) -> RECT {
    unsafe {
        let mon = MonitorFromWindow(hwnd, MONITOR_DEFAULTTONEAREST);
        let mut info: MONITORINFO = std::mem::zeroed();
        info.cbSize = std::mem::size_of::<MONITORINFO>() as u32;
        if GetMonitorInfoW(mon, &mut info) != 0 {
            info.rcWork
        } else {
            // 拿不到时退回超大范围：仅锁比例、不锁屏幕
            RECT { left: i32::MIN / 2, top: i32::MIN / 2, right: i32::MAX / 2, bottom: i32::MAX / 2 }
        }
    }
}

/// 把 WM_SIZING 给出的建议矩形修正为 RATIO 宽高比，并钳制在显示器工作区内。
/// `edge` 为 WMSZ_* 拖动方向；`rect` 是建议窗口矩形（屏幕坐标、物理像素）。
/// 若只按比例推尺寸而不限制屏幕边界，窗口会越界膨胀成比屏幕还大，
/// WebView 渲染表面暴涨 → 卡顿甚至未响应，所以必须在锁比后一并收缩到放得下。
#[cfg(windows)]
fn fix_sizing_rect(edge: u32, rect: &mut RECT, min_w_px: i32, min_h_px: i32, work: &RECT) {
    let ratio = RATIO;
    // 原始建议矩形：锚定边（拖动中不动的那几条边）以它为准
    let (o_l, o_t, o_r, o_b) = (rect.left, rect.top, rect.right, rect.bottom);
    let w = (o_r - o_l) as f64;
    let h = (o_b - o_t) as f64;

    // 1) 按拖动方向 + 比例算出目标尺寸
    let (mut nw, mut nh) = match edge {
        WMSZ_LEFT | WMSZ_RIGHT => {
            let w = w.max(min_w_px as f64);
            (w, w / ratio)
        }
        WMSZ_TOP | WMSZ_BOTTOM => {
            let h = h.max(min_h_px as f64);
            (h * ratio, h)
        }
        // 拖角：偏宽则高度跟上，偏高则宽度跟上
        _ => {
            if h <= 0.0 || w / h >= ratio {
                let w = w.max(min_w_px as f64);
                (w, w / ratio)
            } else {
                let h = h.max(min_h_px as f64);
                (h * ratio, h)
            }
        }
    };
    nw = nw.max(min_w_px as f64);
    nh = nh.max(min_h_px as f64);

    // 2) 钳制到工作区：锚定边不变的前提下，算出可用宽高上限，等比收缩到放得下。
    //    锚定边 = 非拖动的边。左右方向（edge 动横边）锚定哪条竖边、上下方向锚定哪条横边，
    //    据此决定窗口朝哪个方向扩张，进而得到可达的最大宽/高。
    let (anchor_l, anchor_t, anchor_r, anchor_b) = match edge {
        WMSZ_LEFT => (o_r, o_t, o_r, o_b),
        WMSZ_RIGHT => (o_l, o_t, o_l, o_b),
        WMSZ_TOP => (o_l, o_b, o_r, o_b),
        WMSZ_BOTTOM => (o_l, o_t, o_r, o_t),
        WMSZ_TOPLEFT => (o_r, o_b, o_r, o_b),
        WMSZ_TOPRIGHT => (o_l, o_b, o_l, o_b),
        WMSZ_BOTTOMLEFT => (o_r, o_t, o_r, o_t),
        WMSZ_BOTTOMRIGHT => (o_l, o_t, o_l, o_t),
        _ => (o_l, o_t, o_r, o_b),
    };
    // 动左缘（锚右缘）时朝左扩张，上限 = 锚定右缘 - work.left；否则朝右扩张，上限 = work.right - 锚定左缘
    let max_w = match edge {
        WMSZ_LEFT | WMSZ_BOTTOMLEFT | WMSZ_TOPLEFT => (anchor_r - work.left) as f64,
        _ => (work.right - anchor_l) as f64,
    };
    // 动上缘（锚下缘）时朝上扩张，上限 = 锚定下缘 - work.top；否则朝下扩张，上限 = work.bottom - 锚定上缘
    let max_h = match edge {
        WMSZ_TOP | WMSZ_TOPRIGHT | WMSZ_TOPLEFT => (anchor_b - work.top) as f64,
        _ => (work.bottom - anchor_t) as f64,
    };
    let max_w = max_w.max(min_w_px as f64);
    let max_h = max_h.max(min_h_px as f64);
    let fit = (max_w / nw).min(max_h / nh).min(1.0);
    let nw = (nw * fit).round().max(min_w_px as f64) as i32;
    let nh = (nh * fit).round().max(min_h_px as f64) as i32;

    // 3) 按锚定边重定位移动的边：鼠标抓住的边（或角）位置由 OS 建议值决定，另一边实时跟上
    match edge {
        WMSZ_LEFT => {
            rect.left = rect.right - nw;
            rect.bottom = rect.top + nh;
        }
        WMSZ_RIGHT => {
            rect.right = rect.left + nw;
            rect.bottom = rect.top + nh;
        }
        WMSZ_TOP => {
            rect.top = rect.bottom - nh;
            rect.right = rect.left + nw;
        }
        WMSZ_BOTTOM => {
            rect.bottom = rect.top + nh;
            rect.right = rect.left + nw;
        }
        WMSZ_TOPLEFT => {
            rect.left = rect.right - nw;
            rect.top = rect.bottom - nh;
        }
        WMSZ_TOPRIGHT => {
            rect.right = rect.left + nw;
            rect.top = rect.bottom - nh;
        }
        WMSZ_BOTTOMLEFT => {
            rect.left = rect.right - nw;
            rect.bottom = rect.top + nh;
        }
        WMSZ_BOTTOMRIGHT => {
            rect.right = rect.left + nw;
            rect.bottom = rect.top + nh;
        }
        _ => {}
    }
}

/// 窗口过程：拦截 WM_SIZING 实时修正比例，其余转发给旧过程；WM_DESTROY 时恢复。
#[cfg(windows)]
unsafe extern "system" fn cp_wndproc(hwnd: HWND, msg: u32, wparam: WPARAM, lparam: LPARAM) -> LRESULT {
    if msg == WM_SIZING {
        let rect = &mut *(lparam as *mut RECT);
        let scale = GetDpiForWindow(hwnd) as f64 / 96.0;
        let min_w_px = (406.0 * scale).ceil() as i32;
        let min_h_px = (542.0 * scale).ceil() as i32;
        let work = monitor_work_area(hwnd);
        fix_sizing_rect(wparam as u32, rect, min_w_px, min_h_px, &work);
        return 1; // 非零 = 已处理，Windows 按修正后的矩形设置窗口
    }
    if msg == WM_DESTROY {
        // 销毁前恢复原窗口过程，避免悬空函数指针
        SetWindowLongPtrW(hwnd, GWLP_WNDPROC, OLD_WNDPROC.load(Ordering::SeqCst));
    }
    let old: WNDPROC = std::mem::transmute(OLD_WNDPROC.load(Ordering::SeqCst));
    CallWindowProcW(old, hwnd, msg, wparam, lparam)
}

pub fn run() {
    tauri::Builder::default()
        .manage(LastSize(Mutex::new(None)))
        .manage(ResizeDebounce {
            gen: AtomicU64::new(0),
            target: Mutex::new(None),
            animating: AtomicBool::new(false),
        })
        .setup(|app| {
            let cfg = load_config();

            // 基准尺寸 + 恢复记忆尺寸
            let (saved_w, saved_h) = cfg
                .window
                .as_ref()
                .filter(|b| b.width >= 406.0 && b.height >= 542.0)
                .map(|b| (b.width, b.height))
                .unwrap_or((528.0, 704.0));
            // 初值：以高度为基准校正
            let (w0, h0) = enforce_aspect(saved_w, saved_h, saved_w, saved_h);
            let (px, py) = cfg
                .window
                .as_ref()
                .map_or((100.0, 100.0), |b| (b.x.unwrap_or(100) as f64, b.y.unwrap_or(100) as f64));

            // 手动创建窗口：透明圆角融合式外观 + 无系统边框
            let win = WebviewWindowBuilder::new(app, "main", tauri::WebviewUrl::App("index.html".into()))
                .title("调色盘")
                .inner_size(w0, h0)
                .min_inner_size(406.0, 542.0)
                .position(px, py)
                .resizable(true)
                .decorations(false)
                .transparent(true)
                .shadow(false)
                .background_color(tauri::window::Color(0, 0, 0, 0))
                .visible(false)
                .on_page_load(|_win, _payload| {})
                .build()
                .expect("窗口创建失败");

            // 记录初始尺寸（逻辑）供 Resized 校正守卫
            *app.state::<LastSize>().0.lock().unwrap() = Some((w0, h0));

            // Windows 下安装窗口 subclass：拖动中 WM_SIZING 实时锁宽高比
            #[cfg(windows)]
            unsafe {
                let hwnd: HWND = win.hwnd().expect("获取窗口句柄失败").0;
                let old = SetWindowLongPtrW(hwnd, GWLP_WNDPROC, cp_wndproc as *const () as isize);
                OLD_WNDPROC.store(old as isize, Ordering::SeqCst);
            }

            // 状态管理：缩放防抖校正 + 最大化检测（闭包使用 win 的 clone）
            let handle = app.handle().clone();
            let win_evt = win.clone();
            win.on_window_event(move |event| {
                match event {
                    tauri::WindowEvent::Resized(size) => {
                        let scale = win_evt.scale_factor().unwrap_or(1.0);
                        let lw = size.width as f64 / scale;
                        let lh = size.height as f64 / scale;

                        // 最大化状态通知前端（用于去除圆角）
                        let is_max = win_evt.is_maximized().unwrap_or(false);
                        let _ = handle.emit("win:maximize-changed", json!(is_max));
                        if is_max {
                            // 最大化时窗口尺寸由系统控制，不做比例校正
                            *handle.state::<LastSize>().0.lock().unwrap() = Some((lw, lh));
                            return;
                        }

                        // 插值动画进行中：动画自帧触发的 Resized 仅记录实际尺寸，
                        // 不再调度新校正，避免动画自激成环
                        if handle.state::<ResizeDebounce>().animating.load(Ordering::SeqCst) {
                            *handle.state::<LastSize>().0.lock().unwrap() = Some((lw, lh));
                            return;
                        }

                        // 计算目标比例尺寸（方向感知，基准为实际报告尺寸）
                        let state = handle.state::<LastSize>();
                        let mut last = state.0.lock().unwrap();
                        let (tw, th) = match *last {
                            Some((lw0, lh0)) => enforce_aspect(lw, lh, lw0, lh0),
                            None => enforce_aspect(lw, lh, lw, lh),
                        };
                        // 记录实际报告尺寸作为下次判向基准（不是目标尺寸，
                        // 因为拖动中目标并未真正生效，若以目标为基准会误导判向）
                        *last = Some((lw, lh));
                        drop(last);

                        // 若目标与当前一致：已是正确比例，无需校正。
                        // 容差取 2.0 逻辑像素：WM_SIZING 在物理像素上锁比，经 DPI 换算回逻辑后
                        // 会有最多约 1~2 逻辑像素的取整差；容差太紧会在拖动/松手瞬间误触发
                        // 防抖+动画，动画 set_size 与原生拖动循环打架 → 卡顿。
                        if (tw - lw).abs() <= 2.0 && (th - lh).abs() <= 2.0 {
                            return;
                        }

                        // 目标与当前不一致 → 存入待校正目标，并防抖调度一次校正。
                        // 拖动中会持续触发 Resized 递增 gen，旧线程醒来即放弃；
                        // 只有"停止变化约 200ms 后"的那次才真正动窗口（走平滑动画）。
                        let debounce = handle.state::<ResizeDebounce>();
                        let gen = debounce.gen.fetch_add(1, Ordering::SeqCst) + 1;
                        *debounce.target.lock().unwrap() = Some((tw, th));
                        let win_c = win_evt.clone();
                        let handle_c = handle.clone();
                        std::thread::spawn(move || {
                            std::thread::sleep(Duration::from_millis(200));
                            let debounce = handle_c.state::<ResizeDebounce>();
                            if debounce.gen.load(Ordering::SeqCst) == gen {
                                if let Some((tw, th)) = *debounce.target.lock().unwrap() {
                                    animate_resize(&win_c, handle_c.clone(), tw, th);
                                }
                            }
                        });
                    }
                    tauri::WindowEvent::CloseRequested { .. } => {
                        // 仅保存窗口 bounds，不阻止关闭、不递归 close（避免死循环卡死）
                        remember_bounds(&handle);
                    }
                    _ => {}
                }
            });

            let _ = win.show();
            let _ = win.set_focus();
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            win_minimize,
            win_toggle_maximize,
            win_close,
            config_load,
            config_save
        ])
        .run(tauri::generate_context!())
        .expect("Tauri 应用启动失败");
}
